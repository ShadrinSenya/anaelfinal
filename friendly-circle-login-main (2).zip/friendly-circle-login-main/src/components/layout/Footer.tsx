
import React from 'react';
import { MessageCircle } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-cyberDark text-white p-8 mt-auto">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-medium mb-4">Контакты</h3>
          <div className="space-y-2">
            <p className="text-sm text-gray-300">+7 495 181-00-79</p>
            <p className="text-sm text-gray-300">info@cyber-ed.ru</p>
            <p className="text-sm text-gray-300">Москва, Мясницкая улица, 24/7с1</p>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-medium mb-4">Мессенджеры</h3>
          <div className="flex items-center mb-6">
            <a href="#" className="p-2 bg-blue-500 rounded-full hover:bg-blue-600 transition-colors">
              <MessageCircle size={20} />
            </a>
          </div>
          
          <h3 className="text-lg font-medium mb-4">Подписка на рассылку</h3>
          <div className="flex">
            <input 
              type="email" 
              placeholder="E-mail" 
              className="px-4 py-2 bg-white text-black rounded-l-md focus:outline-none w-full max-w-xs"
            />
            <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-r-md transition-colors">
              Подписаться
            </button>
          </div>
        </div>
      </div>
      
      <div className="mt-8 pt-6 border-t border-gray-700">
        <p className="text-xs text-gray-400">© 2023 CyberED. Все права защищены.</p>
      </div>
    </footer>
  );
};

export default Footer;
