
import React, { useState } from 'react';
import { NavLink, useLocation, Link } from 'react-router-dom';
import { Search, User } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

const MainNav = () => {
  const { isAuthenticated, user } = useAuth();
  const location = useLocation();
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <header className="flex flex-col w-full">
      <div className="bg-cyberDark text-white p-4 flex items-center justify-between">
        <div className="flex items-center">
          <label 
            className="flex items-center space-x-2 cursor-pointer"
          >
            <input type="checkbox" className="hidden peer" />
            <div className="w-5 h-5 border border-white/50 rounded flex items-center justify-center">
              <div className="w-3 h-3 bg-white invisible peer-checked:visible"></div>
            </div>
            <span>Личный кабинет</span>
          </label>
        </div>
      </div>

      <div className="cyber-gradient py-4 flex items-center justify-between px-6">
        <NavLink 
          to="/" 
          className="text-white text-3xl font-bold transition-transform hover:scale-105"
        >
          CyberED
        </NavLink>

        <div className="flex items-center">
          <div className="relative mr-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
            <input
              type="text"
              placeholder="Поиск..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white/10 text-white placeholder-white/60 px-10 py-2 rounded-full focus:outline-none focus:bg-white/20 transition-all w-60"
            />
          </div>

          <Link to="/profile" className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
              {user?.avatar ? (
                <img 
                  src={user.avatar} 
                  alt="Аватар" 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <User size={24} className="text-gray-600" />
              )}
            </div>
            <span className="text-white text-xs mt-1 text-center">
              Личный<br />Кабинет
            </span>
          </Link>
        </div>
      </div>

      <nav className="bg-purple-600 border-t border-white/10 p-2 flex items-center space-x-10 px-6 overflow-x-auto">
        <NavLink
          to="/"
          className={({ isActive }) =>
            cn(
              "text-white py-2 transition-all whitespace-nowrap",
              isActive 
                ? "font-semibold" 
                : "hover:text-white/80"
            )
          }
        >
          Главная
        </NavLink>
        <NavLink
          to="/news"
          className={({ isActive }) =>
            cn(
              "text-white py-2 transition-all whitespace-nowrap",
              isActive 
                ? "font-semibold" 
                : "hover:text-white/80"
            )
          }
        >
          Новости
        </NavLink>
        <NavLink
          to="/employees"
          className={({ isActive }) =>
            cn(
              "text-white py-2 transition-all whitespace-nowrap",
              isActive 
                ? "font-semibold" 
                : "hover:text-white/80"
            )
          }
        >
          Сотрудники
        </NavLink>
        <NavLink
          to="/files"
          className={({ isActive }) =>
            cn(
              "text-white py-2 transition-all whitespace-nowrap",
              isActive 
                ? "font-semibold" 
                : "hover:text-white/80"
            )
          }
        >
          Файлы
        </NavLink>
        <NavLink
          to="/forum"
          className={({ isActive }) =>
            cn(
              "text-white py-2 transition-all whitespace-nowrap",
              isActive 
                ? "font-semibold" 
                : "hover:text-white/80"
            )
          }
        >
          Форум
        </NavLink>
        <NavLink
          to="/surveys"
          className={({ isActive }) =>
            cn(
              "text-white py-2 transition-all whitespace-nowrap",
              isActive 
                ? "font-semibold" 
                : "hover:text-white/80"
            )
          }
        >
          Опросы
        </NavLink>
      </nav>
    </header>
  );
};

export default MainNav;
