
import React, { createContext, useState, useContext, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

type User = {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  patronymic: string;
  position: string;
  department: string;
  phone?: string;
  emailContact?: string;
  hobbies?: string[];
  skills?: string[];
  projects?: string[];
  avatar?: string;
};

type AuthContextType = {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
  updateUserProfile: (userData: Partial<User>) => void;
};

type RegisterData = {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  patronymic: string;
  position?: string;
  department?: string;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Проверяем, авторизован ли пользователь при загрузке
    const storedUser = localStorage.getItem('user');
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      // Автоматически создаем демо-пользователя при первом входе
      const demoUser: User = {
        id: '1',
        email: 'demo@cyber-ed.ru',
        firstName: 'Иван',
        lastName: 'Иванов',
        patronymic: 'Иванович',
        position: 'Руководитель проектов',
        department: 'Отдел кадров',
        phone: '+7 999 999 99 99',
        emailContact: 'ivanivanovi11@gmail.com',
        hobbies: ['Футбол', 'баскетбол', 'волейбол', 'графический дизайн'],
        skills: ['Грамотная речь', 'планирование', 'базы данных', 'анализ конкурентов'],
        projects: ['Названия проектов'],
        avatar: ''
      };
      
      setUser(demoUser);
      localStorage.setItem('user', JSON.stringify(demoUser));
    }
    
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      
      // В реальном проекте здесь будет запрос к API
      // Имитируем задержку и проверку учетных данных
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Проверка базовых учетных данных для демонстрации
      if (email === 'demo@cyber-ed.ru' && password === 'password123') {
        const userData: User = {
          id: '1',
          email: 'demo@cyber-ed.ru',
          firstName: 'Иван',
          lastName: 'Иванов',
          patronymic: 'Иванович',
          position: 'Руководитель проектов',
          department: 'Отдел кадров',
          phone: '+7 999 999 99 99',
          emailContact: 'ivanivanovi11@gmail.com',
          hobbies: ['Футбол', 'баскетбол', 'волейбол', 'графический дизайн'],
          skills: ['Грамотная речь', 'планирование', 'базы данных', 'анализ конкурентов'],
          projects: ['Названия проектов'],
          avatar: ''
        };
        
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
        
        toast({
          title: 'Вход выполнен',
          description: 'Вы успешно вошли в систему!',
        });
      } else {
        throw new Error('Неверный email или пароль');
      }
    } catch (error) {
      if (error instanceof Error) {
        toast({
          title: 'Ошибка входа',
          description: error.message,
          variant: 'destructive',
        });
      }
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: RegisterData) => {
    try {
      setIsLoading(true);
      
      // В реальном проекте здесь будет запрос к API
      // Имитируем задержку
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Создаем нового пользователя для демонстрации
      const newUser: User = {
        id: Math.random().toString(36).substring(2, 9),
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        patronymic: userData.patronymic,
        position: userData.position || 'Сотрудник',
        department: userData.department || 'Не указан',
      };
      
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
      
      toast({
        title: 'Регистрация успешна',
        description: 'Аккаунт успешно создан!',
      });
    } catch (error) {
      if (error instanceof Error) {
        toast({
          title: 'Ошибка регистрации',
          description: error.message,
          variant: 'destructive',
        });
      }
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserProfile = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = {...user, ...userData};
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      toast({
        title: 'Профиль обновлен',
        description: 'Изменения сохранены',
      });
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    toast({
      title: 'Выход выполнен',
      description: 'Вы вышли из системы',
    });
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        login, 
        register, 
        logout, 
        updateUserProfile,
        isAuthenticated: !!user,
        isLoading
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
