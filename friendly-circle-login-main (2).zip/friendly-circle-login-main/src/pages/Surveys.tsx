
import React, { useState } from 'react';
import { Plus, Search } from 'lucide-react';

interface Survey {
  id: number;
  title: string;
  description: string;
  completed?: boolean;
}

const Surveys = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [surveys, setSurveys] = useState<Survey[]>([
    { id: 1, title: 'Название опроса', description: 'Описание опроса' },
    { id: 2, title: 'Название опроса', description: 'Описание опроса' },
    { id: 3, title: 'Название опроса', description: 'Описание опроса' },
    { id: 4, title: 'Название опроса', description: 'Описание опроса' },
    { id: 5, title: 'Название опроса', description: 'Описание опроса' },
    { id: 6, title: 'Название опроса', description: 'Описание опроса' },
    { id: 7, title: 'Название опроса', description: 'Описание опроса' },
    { id: 8, title: 'Название опроса', description: 'Описание опроса' },
    { id: 9, title: 'Название опроса', description: 'Описание опроса' },
  ]);

  // Функция фильтрации опросов
  const filteredSurveys = surveys.filter(survey => 
    survey.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    survey.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Функция отметки опроса как завершенного
  const markAsCompleted = (id: number) => {
    setSurveys(prevSurveys => 
      prevSurveys.map(survey => 
        survey.id === id ? { ...survey, completed: !survey.completed } : survey
      )
    );
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 sr-only">Опросы</h1>
      
      <div className="flex justify-between items-center mb-6">
        <div className="relative w-full mr-4">
          <input
            type="text"
            placeholder="Поиск..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 pl-10 bg-indigo-900 text-white placeholder-white/60 border border-purple-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60" size={18} />
        </div>
        
        <button className="p-2 bg-indigo-900 text-white border border-purple-500 rounded-lg hover:bg-indigo-800 transition-colors">
          <Plus size={24} />
        </button>
      </div>
      
      <div className="bg-purple-600 text-white p-6 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Опросы</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {filteredSurveys.map((survey) => (
            <div 
              key={survey.id} 
              className="bg-indigo-900 p-4 rounded-lg cursor-pointer hover:bg-indigo-800 transition-colors"
              onClick={() => markAsCompleted(survey.id)}
            >
              <div className="flex items-start mb-2">
                <div className="w-5 h-5 border border-white rounded flex-shrink-0 mr-3 mt-1 flex items-center justify-center">
                  {survey.completed && <div className="w-3 h-3 bg-white rounded-sm"></div>}
                </div>
                <div>
                  <h3 className="font-semibold">{survey.title}</h3>
                  <p className="text-sm text-white/70">{survey.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {filteredSurveys.length > 9 && (
          <div className="text-right mt-4">
            <button className="text-sm text-white/70 hover:text-white">
              Показать еще...
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Surveys;
