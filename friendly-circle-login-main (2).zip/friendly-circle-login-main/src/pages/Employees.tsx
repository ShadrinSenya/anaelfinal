
import React, { useState } from 'react';
import { User } from 'lucide-react';

const Employees = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Моковые данные сотрудников
  const employees = Array(18).fill(null).map((_, i) => ({
    id: i + 1,
    firstName: 'Иван',
    lastName: 'Иванов',
    patronymic: 'Иванович',
    position: 'Руководитель проектов',
    avatar: ''
  }));
  
  // Фильтрация сотрудников по поисковому запросу
  const filteredEmployees = searchTerm
    ? employees.filter(emp => 
        `${emp.lastName} ${emp.firstName} ${emp.patronymic} ${emp.position}`
          .toLowerCase()
          .includes(searchTerm.toLowerCase())
      )
    : employees;
  
  return (
    <div className="space-y-6">
      <div>
        <input
          type="text"
          placeholder="Введите имя, отдел, роль или другие критерии сотрудника..."
          className="w-full p-3 border border-gray-300 bg-purple-600 text-white placeholder-white/70 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEmployees.map((employee) => (
          <div 
            key={employee.id} 
            className="bg-purple-600 text-white p-6 rounded-lg hover:bg-purple-700 transition-colors cursor-pointer flex items-center space-x-4"
          >
            <div className="w-16 h-16 rounded-full bg-gray-300 flex items-center justify-center">
              {employee.avatar ? (
                <img 
                  src={employee.avatar} 
                  alt={`${employee.firstName} ${employee.lastName}`} 
                  className="w-full h-full object-cover rounded-full" 
                />
              ) : (
                <User size={32} className="text-gray-600" />
              )}
            </div>
            
            <div>
              <h3 className="font-semibold">
                {employee.lastName} <br />
                {employee.firstName} <br />
                {employee.patronymic}
              </h3>
              <p className="text-sm text-purple-200">{employee.position}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Employees;
