
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bell, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const Home = () => {
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();

  // Функция для перехода к недавним сообщениям форума
  const goToRecentMessages = () => {
    navigate('/forum', { state: { activeTab: 'recent' } });
  };

  // Функция для перехода к новостям
  const goToNews = () => {
    navigate('/news');
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Уведомления */}
        <div className="bg-purple-600 text-white p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold flex items-center">
              <Bell className="mr-2" size={20} />
              Уведомления
            </h2>
            <span className="bg-purple-400 text-white text-xs py-1 px-3 rounded-full">
              2
            </span>
          </div>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm font-semibold">2 Новых сообщений на форуме</p>
              <button 
                onClick={goToRecentMessages}
                className="text-xs text-purple-200 underline cursor-pointer"
              >
                Прочитать
              </button>
            </div>
          </div>
        </div>
        
        {/* Опросы */}
        <div className="bg-purple-600 text-white p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">
              Опросы
            </h2>
            <span className="bg-purple-400 text-white text-xs py-1 px-3 rounded-full">
              1
            </span>
          </div>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm font-semibold">Название опроса</p>
              <p className="text-xs text-purple-200 mb-2">
                Описание опроса
              </p>
              <Link 
                to="/surveys"
                className="text-xs bg-purple-500 hover:bg-purple-400 text-white py-1 px-3 rounded inline-block transition-colors"
              >
                Пройти опрос
              </Link>
            </div>
          </div>
        </div>
        
        {/* Баннер */}
        <div className="bg-gray-200 p-6 rounded-lg shadow-md flex items-center justify-center">
          <div className="text-center">
            <h3 className="text-gray-500 mb-2">XXXXXXX</h3>
            <p className="text-gray-400">Место для картинки</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Последние новости */}
        <div className="bg-purple-600 text-white p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">
              Последние новости
            </h2>
            <span className="bg-purple-400 text-white text-xs py-1 px-3 rounded-full">
              3
            </span>
          </div>
          
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="w-16 h-16 bg-gray-300 rounded"></div>
              <div>
                <p className="text-sm font-semibold">Название новости</p>
                <button 
                  onClick={goToNews}
                  className="text-xs text-purple-200 underline cursor-pointer"
                >
                  Прочитать
                </button>
              </div>
            </div>
            
            <div className="flex gap-3">
              <div className="w-16 h-16 bg-gray-300 rounded"></div>
              <div>
                <p className="text-sm font-semibold">Название новости</p>
                <button 
                  onClick={goToNews}
                  className="text-xs text-purple-200 underline cursor-pointer"
                >
                  Прочитать
                </button>
              </div>
            </div>
            
            <div className="flex gap-3">
              <div className="w-16 h-16 bg-gray-300 rounded"></div>
              <div>
                <p className="text-sm font-semibold">Название новости</p>
                <button 
                  onClick={goToNews}
                  className="text-xs text-purple-200 underline cursor-pointer"
                >
                  Прочитать
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Ближайшие события */}
        <div className="bg-purple-500 text-white p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">
              Ближайшие события
            </h2>
            <span className="bg-purple-400 text-white text-xs py-1 px-3 rounded-full">
              3
            </span>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-4xl font-bold">12</div>
                <div className="text-sm">марта</div>
              </div>
              <div>
                <p className="text-sm font-semibold">Название события</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-4xl font-bold">15</div>
                <div className="text-sm">марта</div>
              </div>
              <div>
                <p className="text-sm font-semibold">Название события</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-4xl font-bold">20</div>
                <div className="text-sm">марта</div>
              </div>
              <div>
                <p className="text-sm font-semibold">Название события</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Мои задачи */}
        <div className="bg-purple-600 text-white p-6 rounded-lg shadow-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">
              Мои задачи
            </h2>
            <span className="bg-purple-400 text-white text-xs py-1 px-3 rounded-full">
              4
            </span>
          </div>
          
          <div className="space-y-3">
            <div>
              <p className="text-sm font-semibold">Название задачи</p>
              <div className="flex items-center text-xs text-purple-200">
                <Clock size={12} className="mr-1" />
                1 марта, 14:00
              </div>
            </div>
            
            <div>
              <p className="text-sm font-semibold">Название задачи</p>
              <div className="flex items-center text-xs text-purple-200">
                <Clock size={12} className="mr-1" />
                1 марта, 14:00
              </div>
            </div>
            
            <div>
              <p className="text-sm font-semibold">Название задачи</p>
              <div className="flex items-center text-xs text-purple-200">
                <Clock size={12} className="mr-1" />
                1 марта, 14:00
              </div>
            </div>
            
            <div>
              <p className="text-sm font-semibold">Название задачи</p>
              <div className="flex items-center text-xs text-purple-200">
                <Clock size={12} className="mr-1" />
                1 марта, 14:00
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
