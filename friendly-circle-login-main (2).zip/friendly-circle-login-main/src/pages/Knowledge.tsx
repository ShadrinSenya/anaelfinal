
import React from 'react';

const Knowledge = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6">База знаний</h1>
      
      <div className="bg-purple-600 text-white p-6 rounded-lg">
        <p className="text-center">Страница базы знаний находится в разработке</p>
      </div>
    </div>
  );
};

export default Knowledge;
