
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, User } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

// Тип для комментария
interface Comment {
  id: number;
  author: string;
  authorAvatar?: string;
  text: string;
  date: string;
  likes: number;
  dislikes: number;
}

const News = () => {
  const { toast } = useToast();
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 1,
      author: 'Иванов Иван Иванович',
      text: 'Привет!',
      date: '2 дня назад',
      likes: 0,
      dislikes: 0
    }
  ]);

  const tags = [
    'Разработка', 'Дизайн', 'Маркетинг', 'Менеджмент', 
    'UI/UX', 'Мобильные приложения', 'Веб-разработка',
    'Базы данных', 'AI/ML', 'Frontend', 'Backend'
  ];

  // Функция добавления комментария
  const addComment = () => {
    if (!commentText.trim()) {
      toast({
        title: "Ошибка",
        description: "Комментарий не может быть пустым",
        variant: "destructive",
      });
      return;
    }

    const newComment: Comment = {
      id: comments.length + 1,
      author: 'Вы',
      text: commentText,
      date: 'только что',
      likes: 0,
      dislikes: 0
    };

    setComments([...comments, newComment]);
    setCommentText('');
    
    toast({
      title: "Успешно",
      description: "Комментарий добавлен",
    });
  };

  // Обработка лайков и дизлайков
  const handleReaction = (commentId: number, type: 'like' | 'dislike') => {
    setComments(comments.map(comment => {
      if (comment.id === commentId) {
        if (type === 'like') {
          return { ...comment, likes: comment.likes + 1 };
        } else {
          return { ...comment, dislikes: comment.dislikes + 1 };
        }
      }
      return comment;
    }));
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
      {/* Боковая панель с тегами */}
      <div className="md:col-span-1">
        <div className="bg-purple-600 text-white p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Теги</h2>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, index) => (
              <span 
                key={index} 
                className="bg-white/20 text-white text-xs py-1 px-3 rounded-full hover:bg-white/30 cursor-pointer transition-colors"
              >
                {tag}
              </span>
            ))}
          </div>
          <button className="mt-4 text-sm text-purple-200 hover:text-white">
            Показать ещё...
          </button>
        </div>
      </div>

      {/* Основной контент */}
      <div className="md:col-span-3">
        {/* Поиск */}
        <div className="mb-6">
          <input
            type="text"
            placeholder="Поиск..."
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Статья */}
        <div className="bg-purple-600 text-white p-6 rounded-lg mb-8">
          <div className="mb-4">
            <Link to="/news" className="inline-flex items-center text-purple-200 hover:text-white">
              <ChevronLeft size={16} />
              <span>Назад</span>
            </Link>
          </div>
          
          <h1 className="text-2xl font-bold mb-2">Заголовок заголовок</h1>
          <p className="text-sm mb-6">
            Текст текст текст текст текст текст текст текст текст текст текст текст
            текст текст текст текст текст текст текст текст
          </p>
          
          <div className="mb-6 bg-gray-300 h-32 rounded flex items-center justify-center">
            <span className="text-gray-500">Место для картинки</span>
          </div>
          
          <p className="text-sm mb-6">
            Текст текст текст текст текст текст текст текст текст текст текст текст
            текст текст текст текст текст текст текст текст текст текст текст текст
            текст текст текст текст текст текст текст
          </p>
          
          <p className="text-sm mb-6">
            Текст текст текст текст текст текст текст текст текст текст текст текст
            текст текст текст текст текст текст текст текст текст текст текст текст
            текст текст текст текст текст текст текст
          </p>
          
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-3">Комментарии: {comments.length}</h3>
            
            {/* Форма комментария */}
            <div className="flex gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-gray-300 flex-shrink-0 flex items-center justify-center">
                <User size={20} className="text-gray-600" />
              </div>
              <div className="flex-grow">
                <input
                  type="text"
                  placeholder="Введите здесь свой комментарий..."
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/60 focus:outline-none focus:bg-white/20"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      addComment();
                    }
                  }}
                />
                <div className="flex justify-end mt-2">
                  <button 
                    className="bg-purple-700 hover:bg-purple-800 text-white px-4 py-1 rounded transition-colors"
                    onClick={addComment}
                  >
                    Отправить
                  </button>
                </div>
              </div>
            </div>
            
            {/* Список комментариев */}
            <div className="space-y-6">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <div className="w-10 h-10 rounded-full bg-gray-300 flex-shrink-0 flex items-center justify-center">
                    {comment.authorAvatar ? (
                      <img 
                        src={comment.authorAvatar} 
                        alt={comment.author}
                        className="w-full h-full object-cover rounded-full" 
                      />
                    ) : (
                      <User size={20} className="text-gray-600" />
                    )}
                  </div>
                  <div>
                    <div className="mb-1">
                      <span className="font-semibold">{comment.author}</span>
                    </div>
                    <div className="bg-purple-700/50 p-3 rounded-lg mb-1">
                      <p className="text-sm">{comment.text}</p>
                    </div>
                    <div className="flex gap-4 text-xs text-purple-200">
                      <span>{comment.date}</span>
                      <button className="hover:text-white">Ответить</button>
                      <div className="flex items-center gap-1">
                        <button 
                          className="hover:text-white"
                          onClick={() => handleReaction(comment.id, 'like')}
                        >
                          {comment.likes}
                        </button>
                        <span>•</span>
                        <button 
                          className="hover:text-white"
                          onClick={() => handleReaction(comment.id, 'dislike')}
                        >
                          {comment.dislikes}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default News;
