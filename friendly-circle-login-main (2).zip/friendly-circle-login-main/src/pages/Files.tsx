
import React from 'react';
import { Filter, Plus, MoreVertical, Folder } from 'lucide-react';

const Files = () => {
  const folders = [
    { id: 1, name: 'Название папки' },
    { id: 2, name: 'Название папки' },
    { id: 3, name: 'Название папки' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex gap-4">
        <button className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded transition-colors">
          <Filter size={16} />
          <span>Фильтр</span>
        </button>
        
        <div className="flex-grow">
          <input
            type="text"
            placeholder="Поиск..."
            className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
        
        <button className="flex items-center justify-center bg-purple-600 hover:bg-purple-700 text-white p-2 rounded transition-colors">
          <Plus size={24} />
        </button>
      </div>
      
      <div className="bg-purple-600 text-white p-6 rounded-lg">
        <h2 className="text-xl font-semibold mb-4">Папки</h2>
        
        <div className="space-y-4">
          {folders.map((folder) => (
            <div key={folder.id} className="flex items-center gap-2 bg-blue-600 py-2 px-4 rounded">
              <Folder size={20} />
              <span className="flex-grow">{folder.name}</span>
              <button className="text-white hover:bg-blue-700 p-1 rounded">
                <MoreVertical size={16} />
              </button>
            </div>
          ))}
        </div>
        
        <h2 className="text-xl font-semibold mt-6 mb-4">Документы</h2>
        
        <div className="h-40 flex items-center justify-center">
          <p className="text-white/70">Здесь будут отображаться ваши документы</p>
        </div>
      </div>
    </div>
  );
};

export default Files;
