
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, User } from 'lucide-react';

// Типы для разных видов контента
type Category = {
  id: number;
  name: string;
  description: string;
};

type Topic = {
  id: number;
  title: string;
  author: string;
  authorAvatar?: string;
  date?: string;
};

type Message = {
  id: number;
  category: string;
  title: string;
  author: string;
  authorAvatar?: string;
  date?: string;
  isYours?: boolean;
};

// Вкладки форума
type ForumTab = 'categories' | 'recent' | 'my' | 'subscriptions' | 'search';

const Forum = () => {
  const [activeTab, setActiveTab] = useState<ForumTab>('categories');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Моковые данные категорий форума
  const categories: Category[] = [
    { id: 1, name: 'Название категории', description: 'Описание категории' },
    { id: 2, name: 'Название категории', description: 'Описание категории' },
  ];
  
  // Моковые данные тем форума
  const topics: Topic[] = [
    { id: 1, title: 'Название темы', author: 'Иванов Иван' },
  ];

  // Моковые данные сообщений
  const messages: Message[] = [
    { id: 1, category: 'Название категории', title: 'Название темы', author: 'Иванов Иван', date: '2 часа назад' },
    { id: 2, category: 'Название категории', title: 'Название темы', author: 'Иванов Иван', date: '1 день назад' },
    { id: 3, category: 'Название категории', title: 'Название темы', author: 'Вы', date: '3 дня назад', isYours: true },
  ];

  // Подписки
  const subscriptions: Message[] = [
    { id: 1, category: 'Название категории', title: 'Название темы', author: 'Иванов Иван', date: '5 часов назад' },
    { id: 2, category: 'Название категории', title: 'Название темы', author: 'Петров Петр', date: '2 дня назад' },
  ];

  // Фильтрация сообщений для поиска
  const filteredItems = () => {
    if (!searchTerm) return [];
    
    const allItems = [...categories, ...topics, ...messages];
    return allItems.filter(item => 
      'name' in item 
        ? item.name.toLowerCase().includes(searchTerm.toLowerCase()) || item.description.toLowerCase().includes(searchTerm.toLowerCase())
        : item.title.toLowerCase().includes(searchTerm.toLowerCase()) || item.author.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  // Получить контент в зависимости от активной вкладки
  const getTabContent = () => {
    switch (activeTab) {
      case 'categories':
        return (
          <>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Категории</h2>
              <div className="space-x-2">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                  Добавить категорию
                </button>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                  Новая тема
                </button>
              </div>
            </div>
            
            {/* Категории */}
            <div className="space-y-4 mb-8">
              {categories.map((category) => (
                <div key={category.id} className="bg-blue-800 p-4 rounded-lg flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{category.name}</h3>
                    <p className="text-sm text-blue-200">{category.description}</p>
                  </div>
                  <div className="space-x-2">
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                      Перейти
                    </button>
                    <button className="bg-orange-400 hover:bg-orange-500 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                      Подписаться
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Темы */}
            <h2 className="text-xl font-semibold mb-4">Темы</h2>
            <div className="space-y-4">
              {topics.map((topic) => (
                <div key={topic.id} className="bg-blue-800 p-4 rounded-lg flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{topic.title}</h3>
                    <p className="text-sm text-blue-200">{topic.author}</p>
                  </div>
                  <div className="space-x-2">
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                      Перейти
                    </button>
                    <button className="bg-orange-400 hover:bg-orange-500 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                      Подписаться
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        );
      
      case 'recent':
        return (
          <>
            <h2 className="text-xl font-semibold mb-6">Недавние сообщения</h2>
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className="bg-blue-800 p-4 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
                      {message.authorAvatar ? (
                        <img 
                          src={message.authorAvatar} 
                          alt={message.author} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <User size={20} className="text-gray-600" />
                      )}
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-semibold">{message.title}</h3>
                      <div className="flex text-sm text-blue-200">
                        <span>{message.author}</span>
                        <span className="mx-2">•</span>
                        <span>{message.category}</span>
                        <span className="mx-2">•</span>
                        <span>{message.date}</span>
                      </div>
                    </div>
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                      Ответить
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        );
      
      case 'my':
        return (
          <>
            <h2 className="text-xl font-semibold mb-6">Ваши сообщения</h2>
            <div className="space-y-4">
              {messages.filter(msg => msg.isYours).map((message) => (
                <div key={message.id} className="bg-blue-800 p-4 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
                      {message.authorAvatar ? (
                        <img 
                          src={message.authorAvatar} 
                          alt={message.author} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <User size={20} className="text-gray-600" />
                      )}
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-semibold">{message.title}</h3>
                      <div className="flex text-sm text-blue-200">
                        <span>{message.author}</span>
                        <span className="mx-2">•</span>
                        <span>{message.category}</span>
                        <span className="mx-2">•</span>
                        <span>{message.date}</span>
                      </div>
                    </div>
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                      Перейти
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        );
      
      case 'subscriptions':
        return (
          <>
            <h2 className="text-xl font-semibold mb-6">Ваши подписки</h2>
            <div className="space-y-4">
              {subscriptions.map((subscription) => (
                <div key={subscription.id} className="bg-blue-800 p-4 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
                      {subscription.authorAvatar ? (
                        <img 
                          src={subscription.authorAvatar} 
                          alt={subscription.author} 
                          className="w-full h-full object-cover" 
                        />
                      ) : (
                        <User size={20} className="text-gray-600" />
                      )}
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-semibold">{subscription.title}</h3>
                      <div className="flex text-sm text-blue-200">
                        <span>{subscription.author}</span>
                        <span className="mx-2">•</span>
                        <span>{subscription.category}</span>
                        <span className="mx-2">•</span>
                        <span>{subscription.date}</span>
                      </div>
                    </div>
                    <div className="space-x-2">
                      <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                        Перейти
                      </button>
                      <button className="bg-orange-400 hover:bg-orange-500 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                        Отписаться
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        );
      
      case 'search':
        return (
          <>
            <h2 className="text-xl font-semibold mb-6">Результаты поиска</h2>
            {searchTerm ? (
              filteredItems().length > 0 ? (
                <div className="space-y-4">
                  {filteredItems().map((item, index) => (
                    <div key={index} className="bg-blue-800 p-4 rounded-lg">
                      {'name' in item ? (
                        <div className="flex justify-between items-center">
                          <div>
                            <h3 className="font-semibold">{item.name}</h3>
                            <p className="text-sm text-blue-200">{item.description}</p>
                          </div>
                          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                            Перейти
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
                            <User size={20} className="text-gray-600" />
                          </div>
                          <div className="flex-grow">
                            <h3 className="font-semibold">{item.title}</h3>
                            <p className="text-sm text-blue-200">{item.author}</p>
                          </div>
                          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-lg text-sm transition-colors">
                            Перейти
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-white/70">По вашему запросу ничего не найдено</p>
              )
            ) : (
              <p className="text-center text-white/70">Введите поисковый запрос выше</p>
            )}
          </>
        );
    }
  };
  
  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-6">
        <button 
          className={`py-2 px-4 rounded-lg transition-colors ${activeTab === 'categories' ? 'bg-orange-400 hover:bg-orange-500 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
          onClick={() => setActiveTab('categories')}
        >
          Категории
        </button>
        <button 
          className={`py-2 px-4 rounded-lg transition-colors ${activeTab === 'recent' ? 'bg-orange-400 hover:bg-orange-500 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
          onClick={() => setActiveTab('recent')}
        >
          Недавние сообщения
        </button>
        <button 
          className={`py-2 px-4 rounded-lg transition-colors ${activeTab === 'my' ? 'bg-orange-400 hover:bg-orange-500 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
          onClick={() => setActiveTab('my')}
        >
          Мои сообщения
        </button>
        <button 
          className={`py-2 px-4 rounded-lg transition-colors ${activeTab === 'subscriptions' ? 'bg-orange-400 hover:bg-orange-500 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
          onClick={() => setActiveTab('subscriptions')}
        >
          Мои подписки
        </button>
        
        <div className="flex-grow">
          <div className="relative">
            <input
              type="text"
              placeholder="Поиск"
              className="w-full p-2 border border-gray-300 bg-blue-600 text-white placeholder-white/70 rounded-lg focus:outline-none"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                if (e.target.value) {
                  setActiveTab('search');
                }
              }}
            />
            <button 
              className="absolute right-2 top-1/2 transform -translate-y-1/2"
              onClick={() => setActiveTab('search')}
            >
              <Search className="text-white/70" size={20} />
            </button>
          </div>
        </div>
      </div>
      
      <div className="bg-purple-600 text-white p-6 rounded-lg">
        {getTabContent()}
      </div>
    </div>
  );
};

export default Forum;
