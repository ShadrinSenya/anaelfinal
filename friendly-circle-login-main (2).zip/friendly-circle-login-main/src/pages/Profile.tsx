
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Pencil, User, X, Check } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const Profile = () => {
  const { user, logout, updateUserProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const { toast } = useToast();
  
  // Состояние для полей формы редактирования
  const [editForm, setEditForm] = useState({
    firstName: '',
    lastName: '',
    patronymic: '',
    position: '',
    department: '',
    phone: '',
    emailContact: '',
    hobbies: '',
    skills: '',
    projects: '',
  });
  
  // Инициализация формы данными пользователя при включении режима редактирования
  React.useEffect(() => {
    if (isEditing && user) {
      setEditForm({
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        patronymic: user.patronymic || '',
        position: user.position || '',
        department: user.department || '',
        phone: user.phone || '',
        emailContact: user.emailContact || user.email || '',
        hobbies: user.hobbies?.join(', ') || '',
        skills: user.skills?.join(', ') || '',
        projects: user.projects?.join(', ') || '',
      });
    }
  }, [isEditing, user]);
  
  if (!user) {
    return <div>Loading...</div>;
  }
  
  // Обработчик изменения полей формы
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Обработчик сохранения изменений
  const handleSave = () => {
    const updatedUser = {
      firstName: editForm.firstName,
      lastName: editForm.lastName,
      patronymic: editForm.patronymic,
      position: editForm.position,
      department: editForm.department,
      phone: editForm.phone,
      emailContact: editForm.emailContact,
      hobbies: editForm.hobbies.split(',').map(item => item.trim()).filter(Boolean),
      skills: editForm.skills.split(',').map(item => item.trim()).filter(Boolean),
      projects: editForm.projects.split(',').map(item => item.trim()).filter(Boolean),
    };
    
    updateUserProfile(updatedUser);
    setIsEditing(false);
    
    toast({
      title: "Профиль обновлен",
      description: "Ваши изменения были успешно сохранены",
    });
  };
  
  // Обработчик отмены редактирования
  const handleCancel = () => {
    setIsEditing(false);
  };
  
  // Список отделов для выбора
  const departments = [
    'Отдел кадров',
    'IT отдел',
    'Финансовый отдел',
    'Маркетинг',
    'Производство',
    'Продажи',
    'Администрация'
  ];
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-gradient-to-r from-purple-600 to-blue-700 text-white p-8 rounded-lg shadow-md mb-6">
        <div className="flex items-end justify-end mb-2">
          {isEditing ? (
            <div className="space-x-2">
              <button 
                onClick={handleSave} 
                className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded transition-colors flex items-center gap-2"
              >
                <Check size={16} />
                Сохранить
              </button>
              <button 
                onClick={handleCancel} 
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded transition-colors flex items-center gap-2"
              >
                <X size={16} />
                Отмена
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setIsEditing(true)} 
              className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded transition-colors flex items-center gap-2"
            >
              <Pencil size={16} />
              Редактировать
            </button>
          )}
        </div>
        
        <div className="flex flex-col md:flex-row gap-8">
          <div className="w-36 h-36 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
            {user.avatar ? (
              <img 
                src={user.avatar} 
                alt="Аватар пользователя" 
                className="w-full h-full object-cover" 
              />
            ) : (
              <User size={64} className="text-gray-600" />
            )}
          </div>
          
          <div className="flex-grow">
            {isEditing ? (
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="text-white/70 block mb-1">Фамилия</label>
                  <input
                    type="text"
                    name="lastName"
                    value={editForm.lastName}
                    onChange={handleChange}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                  />
                </div>
                <div>
                  <label className="text-white/70 block mb-1">Имя</label>
                  <input
                    type="text"
                    name="firstName"
                    value={editForm.firstName}
                    onChange={handleChange}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                  />
                </div>
                <div>
                  <label className="text-white/70 block mb-1">Отчество</label>
                  <input
                    type="text"
                    name="patronymic"
                    value={editForm.patronymic}
                    onChange={handleChange}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                  />
                </div>
              </div>
            ) : (
              <h1 className="text-2xl font-bold">
                {user.lastName}<br />
                {user.firstName}<br />
                {user.patronymic}
              </h1>
            )}
            
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h2 className="text-white/70">Должность</h2>
                {isEditing ? (
                  <input
                    type="text"
                    name="position"
                    value={editForm.position}
                    onChange={handleChange}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                  />
                ) : (
                  <p className="text-xl">{user.position || 'Не указана'}</p>
                )}
              </div>
              
              <div>
                <h2 className="text-white/70">Отдел</h2>
                {isEditing ? (
                  <select
                    name="department"
                    value={editForm.department}
                    onChange={handleChange}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                  >
                    <option value="">Выберите отдел</option>
                    {departments.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                ) : (
                  <p className="text-xl">{user.department || 'Не указан'}</p>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 border border-white/20 rounded-lg p-4">
          <h3 className="text-xl mb-4">Контактная информация</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-white/70">Телефон</p>
              {isEditing ? (
                <input
                  type="text"
                  name="phone"
                  value={editForm.phone}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                />
              ) : (
                <p>{user.phone || 'Не указан'}</p>
              )}
            </div>
            <div>
              <p className="text-white/70">Email</p>
              {isEditing ? (
                <input
                  type="email"
                  name="emailContact"
                  value={editForm.emailContact}
                  onChange={handleChange}
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                />
              ) : (
                <p>{user.emailContact || user.email}</p>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <h3 className="text-xl mb-4">Дополнительная информация</h3>
          <div className="space-y-4">
            <div>
              <p className="text-white/70">Хобби:</p>
              {isEditing ? (
                <textarea
                  name="hobbies"
                  value={editForm.hobbies}
                  onChange={handleChange}
                  placeholder="Введите хобби через запятую"
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                />
              ) : (
                <p>{user.hobbies?.join(', ') || 'Не указаны'}</p>
              )}
            </div>
            
            <div>
              <p className="text-white/70">Навыки:</p>
              {isEditing ? (
                <textarea
                  name="skills"
                  value={editForm.skills}
                  onChange={handleChange}
                  placeholder="Введите навыки через запятую"
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                />
              ) : (
                <p>{user.skills?.join(', ') || 'Не указаны'}</p>
              )}
            </div>
            
            <div>
              <p className="text-white/70">Проекты:</p>
              {isEditing ? (
                <textarea
                  name="projects"
                  value={editForm.projects}
                  onChange={handleChange}
                  placeholder="Введите проекты через запятую"
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded text-white"
                />
              ) : (
                <p>{user.projects?.join(', ') || 'Не указаны'}</p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col items-center space-y-4">
        <button 
          onClick={logout}
          className="w-64 bg-purple-600 hover:bg-purple-700 text-white py-3 px-4 rounded-md transition-colors"
        >
          Выйти
        </button>
        
        <Link 
          to="/"
          className="text-gray-600 hover:text-purple-800 transition-colors"
        >
          Вернуться на главную страницу
        </Link>
      </div>
    </div>
  );
};

export default Profile;
